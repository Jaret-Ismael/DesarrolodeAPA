from registration import admin, urls


def test():
    assert admin
    assert urls
