.. _release-notes:

Release notes
=============

The |version| release of |project| supports Python 2.7, 3.4, 3.5 and
Django 1.8, 1.9, and 1.10.
